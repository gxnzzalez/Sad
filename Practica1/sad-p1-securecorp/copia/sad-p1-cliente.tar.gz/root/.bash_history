mkdir -p ldif
cd ldif
nano 01-ejemplo.ldif
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Lucia2026' "uid=lromero,ou=people,dc=securecorp,dc=local"
nano 02-tu-turno.ldif
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Sergio2026' "uid=sgonzalez,ou=people,dc=securecorp,dc=local"
cd ..
nano /etc/ldap/ldap.conf
echo 'TLS_CACERT /pki/ca/ca.crt' >> /etc/ldap/ldap.conf
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026' 
ldapwhoami -x -H ldap://ldap.securecorp.local  -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
nano /etc/ldap/ldap.conf
ldapwhoami -x -H ldap://ldap.securecorp.local  -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026' 
kinit sgonzalez
kvno host/web.securecorp.local
klist
kdestroy
kinit lromero
klist
kdestroy
exit
ls
cd ldif
nano 02-tu-turno.ldif 
exit
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" uid
exit
clear
exit
