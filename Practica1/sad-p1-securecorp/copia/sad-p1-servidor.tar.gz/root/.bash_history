mkdir -p /etc/ldap/tls
cp /pki/ca/ca.crt /pki/servidor/ldap.crt /pki/servidor/ldap.key /etc/ldap/tls/
chown -R openldap:openldap /etc/ldap/tls
chmod 600 /etc/ldap/tls/ldap.key
ls -l /etc/ldap/tls
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif
nano /etc/default/slapd
nano /etc/default/slapd
exit
kdb5_util create -s -r SECURECORP.LOCAL
service krb5-kdc start
kadmin.local -q "addprinc lromero"
kadmin.local -q "addprinc sgonzalez"
kadmin.local -q "addprinc mtorres"
kadmin.local -q "addprinc -randkey host/web.securecorp.local"
kadmin.local -q "listprincs"
exit
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(objectClass=inetOrgPerson)" uid
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" uid
ldapsearch -x -LLL -H ldap://ldap.securecorp.local -b "ou=groups,dc=securecorp,dc=local" "(cn=rrhh)" uid
./lab.sh cliente
exit
cd /etc
ls
dc ldap
cd ldap
ls
cd ..
ls
cd ..
clear
exit
