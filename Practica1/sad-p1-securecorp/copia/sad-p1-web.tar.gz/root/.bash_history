kinit sgonzalez
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=TUUSUARIO,ou=people,dc=securecorp,dc=local" -W
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=TUUSUARIO,ou=people,dc=securecorp,dc=local" -W
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=sgonzalez,ou=people,dc=securecorp,dc=local" -W
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=sgonzalez,ou=people,dc=securecorp,dc=local" -W
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=sgonzalez,ou=people,dc=securecorp,dc=local" -W
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=sgonzalez,ou=people,dc=securecorp,dc=local" -W
exit
